function nueva_relacion_a_a(actorId){
    var windowSizeArray = [ "width=770,height=535,scrollbars=yes" ];
    window.open(base+'index.php/actores_c/agregar_relacion_actor/'+actorId, 'Relacion entre actores individuales', windowSizeArray);
}