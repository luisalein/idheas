/***Script para que funcione el date picker****/
$(function() {
	$( "#desdeFechaReporte" ).datepicker({ dateFormat: "yy-mm-dd"});
	 });
	 
$(function() {
	$( "#hastaFechaReporte" ).datepicker({ dateFormat: "yy-mm-dd"});
	 }	 );
		 
function algo(){
	alert("Algo");
}