<pre><?

print_r($reporte);

print_r($catalogos);


?></pre>