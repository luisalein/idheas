<fieldset> <!--Información general-->
	  <legend>Información general</legend>
	<div class="six columns">

		<h6 >Nombre:   </h6>
		<label id="nombre"><?=(isset($datosActor['actores']['nombre'])) ? $datosActor['actores']['nombre'] : ''; ?></label>

		<h6 >Siglas:  </h6>
		<label id="apellidosSiglas"><?=(isset($datosActor['actores']['apellidosSiglas'])) ? $datosActor['actores']['apellidosSiglas'] : ''; ?></label>
	 
	</div> 
	
	<div class="six columns">

		<h6 >Tipo de actor colectivo:  </h6>
		<label id="tipoActorColectivoId"><?=(isset($datosActor['infoGralActores']['tipoActorColectivoId'])) ? $datosActor['infoGralActores']['tipoActorColectivoId'] : ''; ?></label>

		<h6 >Actividad:  </h6>
		<label id="actividad"><?=(isset($datosActor['infoGralActores']['actividad'])) ? $datosActor['infoGralActores']['actividad'] : ''; ?></label>
	
	</div>
</fieldset>	<!--Termina información general-->


<fieldset> <!--Dirección-->
	  <legend>Dirección</legend>
		<div class="six columns">

			<h6 >Ubicación:   </h6>
			<label id="direccion"><?=(isset($datosActor['direccionActor']['direccion'])) ? $datosActor['direccionActor']['direccion'] : ''; ?></label>

			<h6 >País:  </h6>
			<label id="paisesCatalogo_paisId"><?=(isset($datosActor['direccionActor']['paisesCatalogo_paisId'])) ? $datosActor['direccionActor']['paisesCatalogo_paisId'] : ''; ?></label>

			<h6 >Estado:  </h6>
			<label id="estadosCatalogo_estadoId"><?=(isset($datosActor['direccionActor']['estadosCatalogo_estadoId'])) ? $datosActor['direccionActor']['estadosCatalogo_estadoId'] : ''; ?></label>

		</div> 
		
		<div class="six columns">
			
			<h6 >Municipio:  </h6>
			<label id="municipiosCatalogo_municipioId"><?=(isset($datosActor['direccionActor']['municipiosCatalogo_municipioId'])) ? $datosActor['direccionActor']['municipiosCatalogo_municipioId'] : ''; ?></label>

			<h6 >Código postal:  </h6>
			<label id="actores_codigoPostal"><?=(isset($datosActor['actores']['actores_codigoPostal'])) ? $datosActor['actores']['actores_codigoPostal'] : ''; ?></label>

		</div>
</fieldset>	<!--Termina información direccion-->

		
		<fieldset> <!--Dirección-->
			  <legend>Información de contacto</legend>
			<div class="six columns">

				<h6 >Teléfono:   </h6>
				<label id="telefono"><?=(isset($datosActor['infoContacto']['telefono'])) ? $datosActor['infoContacto']['telefono'] : ''; ?></label>

				<h6 >Fax:  </h6>
				<label id="fax"><?=(isset($datosActor['infoContacto']['fax'])) ? $datosActor[$actorId]['infoContacto'] : ''; ?></label>

			</div> 
			
			<div class="six columns">

				<h6 >Correo electrónico:  </h6>
				<label id="correoE"><?=(isset($datosActor['infoContacto']['correoE'])) ? $datosActor['infoContacto']['correoE'] : ''; ?></label>

				<h6 >Página web:  </h6>
				<label id="paginaWeb"><?=(isset($datosActor['infoGralActores']['paginaWeb'])) ? $datosActor['infoGralActores']['paginaWeb'] : ''; ?></label>

			</div>
		</fieldset>	<!--Termina información general-->
