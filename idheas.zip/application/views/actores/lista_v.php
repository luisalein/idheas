<div><!--Lista de Actores-->   
    <form  method="post" accept-charset="utf-8" id="formEditarActor">
        <input id="<?=$is_active; ?>_nombre" type="text"  name="<?=$is_active; ?>_nombre"  placeholder="<?=($is_active == 'actores') ? 'Buscar por nombre o apellido' : 'Buscar por nombre del caso' ; ?>" class="seven columns" />
    </form>
    <div class="twelve columns">
        <h1><div class="six columns">Foto</div></h1>
        <h1><div class="six columns">Nombre</div></h1>
    </div>
    <!------------Lista ind-------------------->
    <div  id="listaActorIndiv" class="PruebaScorll">
        <?php if(isset($listado) && $listado != null){
            if($is_active == 'actores'){
                foreach($listado as $actor): ?>
                <div class="twelve columns">
                    <img class="five columns" src="<?=base_url(); ?>statics/media/img/actores/<?=$actor['actorId']; ?>.jpg" />
                    <a href="<?=base_url(); ?>index.php/actores_c/mostrar_actor/<?=$actor['actorId']; ?>/<?=$is_actor_type; ?>" class="seven columns">
                        <?=$actor['nombre'].' '.$actor['apellidosSiglas']; ?>
                    </a>
                </div>
                <hr />
            <?php endforeach;
            } else {
                foreach($listado as $caso): ?>
                <div class="twelve columns">
                    <a href="<?=base_url(); ?>index.php/casos_c/mostrar_caso/<?=$caso['casoId']; ?>" class="seven columns">
                        <?=$actor['nombre']; ?>
                    </a>
                </div>
                <hr />
            <?php endforeach;
            }
        } ?>
    </div><!--Termina lista de los actores-->
</div>