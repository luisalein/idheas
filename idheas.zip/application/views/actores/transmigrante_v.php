<fieldset> <!--Información general-->
	  <legend>Información general</legend>
	<div class="six columns">
	 
		<h6>Nombre:   </h6>
		<label id="nombre"><?=(isset($datosActor['actores']['nombre'])) ? $datosActor['actores']['nombre'] : ''; ?></label>
	 
		<h6>Apellidos:  </h6>
		<label id="apellidosSiglas"><?=(isset($datosActor['actores']['apellidosSiglas'])) ? $datosActor['actores']['apellidosSiglas'] : ''; ?></label>
	 
		<h6>Alias:   </h6>
		<label id="alias"><?=(isset($datosActor['alias']['alias'])) ? $datosActor['alias']['alias'] : ''; ?></label>
	  
	  
	</div>
	  
	<div class="six columns">
	  
		<div class="six columns">
		 
			<h6>Género:   </h6>
			<label id="generoid"><?=(isset($datosActor['infoGralActor']['generoid'])) ? $datosActor['infoGralActor']['generoid'] : ''; ?></label>
		
		</div>
	
		<div class="six columns">
			<h6>Edad:   </h6>
			<label id="edad"><?=(isset($datosActor['infoGralActor']['edad'])) ? $datosActor['infoGralActor']['edad'] : ''; ?></label>
		</div>
	 
		<h6>Estado Civil:   </h6>
		<label id="estadoCivil_estadoCivilId"><?=(isset($datosActor['infoGralActor']['estadoCivil_estadoCivilId'])) ? $datosActor['infoGralActor']['estadoCivil_estadoCivilId'] : ''; ?></label>
	 
		<h6>Nacionalidad:   </h6>
		<label id="nacionalidadId"><?=(isset($datosActor['infoGralActor']['nacionalidadId'])) ? $datosActor['infoGralActor']['nacionalidadId'] : ''; ?></label>
	
	</div> 
</fieldset>	<!--Termina información general-->

<fieldset> <!--Detalles-->
	<legend>Detalles:   </legend>
	<div class="six columns">

		 <div class="six columns">
				<h6>Hijos:   </h6>
				<label id="hijos" ><?=(isset($datosActor['infoGralActor']['hijos'])) ? $datosActor['infoGralActor']['hijos'] : ''; ?></label>
		 </div>
		  
		 <div class="six columns">									
			<h6>¿Habla español?:   </h6>
			<label id="espaniol"><?=(isset($datosActor['infoGralActor']['espaniol'])) ? $datosActor['infoGralActor']['espaniol'] : ''; ?></label>
		 </div>

		<h6>Grupo Indígena:   </h6>
		<label id="gruposIndigenas_grupoIndigenaId"><?=(isset($datosActor['infoGralActor']['gruposIndigenas_grupoIndigenaId'])) ? $datosActor['infoGralActor']['gruposIndigenas_grupoIndigenaId'] : ''; ?></label>

	</div>

	<div class="six columns">
	  
		<h6>Nivel de Escolaridad:   </h6>
		<label id="escolaridadId"><?=(isset($datosActor['infoGralActor']['escolaridadId'])) ? $datosActor['infoGralActor']['escolaridadId'] : ''; ?></label>	
		
		<h6>Última Ocupación:   </h6>
		<label id="ocupacionesCatalogo_ultimalOcupacionid"><?=(isset($datosActor['infoGralActor']['ocupacionesCatalogo_ultimalOcupacionid'])) ? $datosActor['infoGralActor']['ocupacionesCatalogo_ultimalOcupacionid'] : ''; ?></label>
			 
	</div>	
</fieldset><!--Termina Detalles-->

<fieldset>	
	  <legend>Información Migratoria</legend>

	<div class="twelve columns">
		<fieldset>		
			<legend>Lugar de origen</legend>

			<div class="four columns">		
				<h6 >País: </h6>
				<div id="paisesCatalogo_paisId"><?=(isset($datosActor['datosDeNacimiento']['paisesCatalogo_paisId'])) ? $datosActor['datosDeNacimiento']['paisesCatalogo_paisId'] : ''; ?></div>
			</div>
			
			<div class="four columns">
				<h6>Estado: </h6>
				<div id="estadosCatalogo_estadoId"><?=(isset($datosActor['datosDeNacimiento']['estadosCatalogo_estadoId'])) ? $datosActor['datosDeNacimiento']['estadosCatalogo_estadoId'] : ''; ?></div>
			</div>
			
			<div class="four columns">							
				<h6>Municipio: </h6>
				<div id="municipiosCatalogos_municipiosId" ><?=(isset($datosActor['datosDeNacimiento']['municipiosCatalogos_municipiosId'])) ? $datosActor['datosDeNacimiento']['municipiosCatalogos_municipiosId'] : ''; ?></div>
			</div>

		</fieldset>	<!--Termina lugar de origen-->
	</div>							

	<div class="six columns">
			<h6>País de tránsito: </h6>
				<div id="paisTransitoId"><?=(isset($datosActor['infoMigratoria']['paisTransitoId'])) ? $datosActor['infoMigratoria']['paisTransitoId'] : ''; ?></div>
														
			<h6>País destino: </h6>
				<div id="paisDestinoId"><?=(isset($datosActor['infoMigratoria']['paisDestinoId'])) ? $datosActor['infoMigratoria']['paisDestinoId'] : ''; ?></div>

			<h6>Intentos de cruce por el país de tránsito: </h6>
				<div id="infoMigratoria_IntCrucesTransitoV" ><?=(isset($datosActor['infoMigratoria']['intCruceTransito'])) ? $datosActor['infoMigratoria']['intCruceTransito'] : ''; ?></div>
				
			<h6>Comentarios:</h6>
			  <div id="comentarios" ><?=(isset($datosActor['infoMigratoria']['comentarios'])) ? $datosActor['infoMigratoria']['comentarios'] : ''; ?></div>

			<h6>Expulsiones del país de destino: </h6>
				<div id="expCruceDestino"><?=(isset($datosActor['infoMigratoria']['expCruceDestino'])) ? $datosActor['infoMigratoria']['expCruceDestino'] : ''; ?></div>

	</div>
	<div class="six columns">

		<h6>Motivo del viaje: </h6>
			<div id="motivoViaje"><?=(isset($datosActor['infoMigratoria']['motivoViaje'])) ? $datosActor['infoMigratoria']['motivoViaje'] : ''; ?></div>

		<h6>Tipo de estancia:</h6>
			<div id="tipoEstanciaId"><?=(isset($datosActor['infoMigratoria']['tipoEstanciaId'])) ? $datosActor['infoMigratoria']['tipoEstanciaId'] : ''; ?></div>

		<h6>Realiza el viaje:</h6>
			<div id="realizaViaje" ><?=(isset($datosActor['infoMigratoria']['realizaViaje'])) ? $datosActor['infoMigratoria']['realizaViaje'] : ''; ?></div>

		<h6>Intentos de cruce al país destino: </h6>
			<div id="intCrucesDest" ><?=(isset($datosActor['infoMigratoria']['intCrucesDest'])) ? $datosActor['infoMigratoria']['intCrucesDest'] : ''; ?></div>

		<h6>Expulsiones del país de tránsito: </h6>
			<div id="expCruceTransito"> <?=(isset($datosActor['infoMigratoria']['expCruceTransito'])) ? $datosActor['infoMigratoria']['expCruceTransito'] : ''; ?></div>

	</div>
	
</fieldset><!--Termina datos de nacimiento-->

