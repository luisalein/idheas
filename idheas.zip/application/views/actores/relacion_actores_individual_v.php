<!---Comienza la parte de detalles del lugar-->
<html>
<head>
    <?=$head; ?>
</head>

<body>
<div id="FormularioRelacionIndividuos">
<form action="<?=base_url(); ?>index.php/actores_c/guardar_relacion" method="post" accept-charset="utf-8">
<input type="hidden" name="actores_actorId" value="<?=$actorId;?>" />	
<input type="hidden"  id="tipoRelacionIndividualColectivoId" name="tipoRelacionIndividualColectivoId" value="1"/>

<div class="twelve columns">
<label for="TipoRel">Tipo de relación</label>
<select id="relacionActores" name="tipoRelacionId">
<?php if(isset($catalogos['relacionActoresCatalogo'])){ ?>
<?php foreach($catalogos['relacionActoresCatalogo'] as $index => $item):?> 
<option value="<?php print_r($item['tipoRelacionId']); ?>"><?php print_r($item['nombre']); ?> </option>
<?php endforeach;?><!--Termina lista de los actores-->
<?php } ?>
</select>
</div>
<br /><br />
<label for="PerRelacionada">Persona Relacionada</label>

<div  id="listaPersonaRelacionada" class="casosScorll">
<?php if(isset($listaActores['individual'])){ ?>
<?php foreach($listaActores['individual']  as $index => $item):?> <!--muestra cada elemento de la lista-->

<div class="cambiarColor twelve columns" id="personaRelacionada<?=$item['actorId']?>" onclick="personaRelacionada('<?=$item['actorId']?>')">  <!--funcion interventor-->
<div class="seven columns"><!--imprimo imagenes-->
<?php echo img($item['actorId']);?>
<?=$item['nombre']?>
<?php echo br(2);?>	
</div>
</div>

<?php endforeach;?><!--Termina lista de los actores-->
<?php } ?>

<?php if(isset($listaActores['transmigrante'])){ ?>
<?php foreach($listaActores['transmigrante'] as $index => $item):?> <!--muestra cada elemento de la lista-->

<div class="cambiarColor twelve columns" id="personaRelacionada<?=$item['actorId']?>" onclick="personaRelacionada('<?=$item['actorId']?>')"> 
<div class="seven columns" ><!--imprimo imagenes-->
<?php echo img($item['actorId']);?>
<?=$item['nombre']?>
<?php echo br(2);?>	
</div>
</div>

<?php endforeach;?><!--Termina lista de los actores-->
<?php } ?>
</div>


<br /><br />
<div class="twelve columns">
<label for="edad">Fecha inicial</label>
<?php echo br(1);?>	

<input type="text" id="fechaExactaRP" name="fechaInicial" <?=(isset($relaciones) ? 'value="'.$relaciones[$actorId]['fechaInicial'].'"' : ''); ?> placeholder="AAAA-MM-DD" />

</div> <!---termina opciones de fechaInicial---->

<div class="twelve columns" >
<label for="Termonio">Fecha término</label>
<input type="text" id="fechaExacta2RP" name="fechaTermino" <?=(isset($relaciones) ? 'value="'.$relaciones[$actorId]['fechaTermino'].'"' : ''); ?> placeholder="AAAA-MM-DD" />

</div> <!---termina opciones de fechaTermino-->

<br /><br />
<div  id="pestania" data-collapse>
<h2 class="open">Comentarios</h2>
<div class="twelve columns">
<textarea id="TextoRelActores" style="width: 400px; height: 200px" wrap="hard"  name="comentarios"></textarea>
<script>
var instance = new TINY.editor.edit('editor', {
id: 'TextoRelActores',
width: 500,
height: 175,
cssclass: 'tinyeditor',
controlclass: 'tinyeditor-control',
rowclass: 'tinyeditor-header',
dividerclass: 'tinyeditor-divider',
controls: ['bold', 'italic', 'underline', '|', 'leftalign','centeralign', 'rightalign', 'blockjustify', '|', 'undo', 'redo'],
footer: false,
xhtml: false,
content:<?=(isset($relaciones) ? 'value="'.$relaciones[$actorId]['comentarios'].'"' : ''); ?>,
bodyid: 'editor',
toggle: {text: 'source', activetext: 'wysiwyg', cssclass: 'toggle'},
resize: {cssclass: 'resize'}
});
</script>
</div>	  

</div>	
<input class="medium button" type="submit" value="Guardar" />
<input class="medium button" type="button" value="Cancelar"  onclick="cerrarVentana()"/>

</form>		
</div>	
</body>
</html>