<form>
	<div class="twelve columns">
		<label for="nombre">Nombre del casos</label>
		<input type="text" id="nombreDelCasos" name="actores_nombre"  required />
	</div>	
	<input class="medium button" type="submit" value="Guardar" />

</form>

<form>
	<div class="twelve columns">
	<div class="six columns">
		<label for="fechaInicia">Desde la fecha</label>
		<input type="text" id="desdeFechaReporte" name="desdeFechaReporte" placeholder="AAAA-MM-DD" />
	</div>		
	<div class="six columns">
		<label for="fechaTermina">Hasta la fecha</label>
		<input type="text" id="hastaFechaReporte" name="hastaFechaReporte" placeholder="AAAA-MM-DD" />
	</div>
		<input class="medium button" type="submit" value="Guardar" />
	</div>
</form>
