<div id="pestania" data-collapse>
	<h2 class="open">Núcleo caso</h2><!--título de la sub-pestaña---->  
	<div>
	  	<div id="subPestanias" data-collapse>
	  		<h2 class="open">Derechos afectados y actos</h2>
	  		<div>
	  			<div>
	  				<table>
			            <thead>
			              <tr>
			                <th>Derecho humano</th>
			                <th>Acto</th>
			                <th>Fecha inicio</th>
			                <th>Fecha término</th>
			                <th>Acción(es)</th>
			              </tr>
			            </thead>
			            <tbody>
			              <tr>
			                <td><span id="descho_fichaId"><?=(isset($datosCaso['derechoAfectado'][2]['derechoAfectadoCasoId'])) ? $datosCaso['actos'][2]['actoViolatorioId'] : ''; ?></span></td>
			                <td><span id="descho_fichaId"><?=(isset($datosCaso['derechoAfectado'][2]['actoViolatorioNivel'])) ? $datosCaso['actos'][2]['actoViolatorioNivel'] : ''; ?></span></td>
			                <td><span id="descho_fichaId"><?=(isset($datosCaso['derechoAfectado'][2]['fechaInicial'])) ? $datosCaso['derechoAfectado'][2]['fechaInicial'] : ''; ?></span></td>
			                <td><span id="descho_fichaId"><?=(isset($datosCaso['derechoAfectado'][2]['fechaTermino'])) ? $datosCaso['derechoAfectado'][2]['fechaTermino'] : ''; ?></span></td>
			                <td><input type="button" class="tiny button"  value="Editar" onclick="ventanaDerAfectados()" />
			                <input type="button" class="tiny button"  value="Eliminar" onclick="ventanaDerAfectados()" /></td>
			              </tr>
			            </tbody>
			          </table>
			    <input type="button" class="tiny button"  value="Nuevo" onclick="ventanaDerAfectados(<?=$casoId; ?>)" />
	  			</div>
	  			  
	  		</div>

	  	</div><!--fin acordeon Derechos afectados y actos-->

<pre><?php print_r($datosCaso)?> </pre>
<pre><?php print_r($datosCaso['actos'][2]['fechaTermino'])?> </pre>
<pre><?php print_r($catalogos['tipoIntervencion'])?>		</pre>
	  	<div id="subPestanias" data-collapse>
	  		<h2 class="open">Intervenciones</h2>
	  		<div>
	  			<div>
	  				<table>
			            <thead>
			              <tr>
			                <th>Receptor</th>
			                <th>Interventor</th>
			                <th>Tipo de intervención</th>
			                <th>Fecha</th>
			                <th>Acción(es)</th>
			              </tr>
			            </thead>
			            <tbody>

			              <?php if(isset($datosCaso['intervenciones'])){ ?>
			              <?php foreach ($datosCaso['intervenciones'] as $inter) {?>
			              	 <tr>
			                <td><span id="descho_fichaId"><?=(isset($inter['receptorId'])) ? $inter['receptorId'] : ''; ?></span></td>
			                <td><span id="descho_fichaId"><?=(isset($inter['interventorId'])) ? $inter['interventorId'] : ''; ?></span></td>
			                <td><span id="descho_fichaId"><?=(isset($inter['IntervencionNId'])) ? $catalogos['tipoIntervencion']['tipoIntervencionN'.$inter['IntervencionNId'].'Catalogo'][$inter['tipoIntervencionId']-2]['descripcion'] : ''; ?></span></td>
			                <td><span id="descho_fichaId"><?=(isset($inter['fecha'])) ? $inter['fecha'] : ''; ?></span>	</td>
			                <td><input type="button" class="tiny button"  value="Editar" onclick="ventanaInterevenciones()" />
			                <input type="button" class="tiny button"  value="Eliminar" onclick="ventanaInterevenciones()" /></td>
			              </tr> <?php } }?>
			            </tbody>
			          </table>
				<input type="button" class="tiny button"  value="Nuevo" onclick="ventanaInterevenciones(<?=$casoId; ?>)" />	  
	  			</div>
	  			  
	  		</div>
	  	</div><!--fin acordeon Intervenciones-->
	</div>
	  
</div><!--fin acordeon Núcleo caso-->