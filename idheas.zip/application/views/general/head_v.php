<title>Id(h)eas</title>
<meta charset ="utf-8" />
<meta name="viewport" content="width=device-width" />
<link rel="stylesheet" href="<?=base_url(); ?>statics/css/style.css">
<script src="<?=base_url(); ?>statics/js/foundation/modernizr.foundation.js" ></script>
<script src="<?=base_url(); ?>statics/js/foundation/foundation.min.js" ></script>
<script src="<?=base_url(); ?>statics/js/foundation/app.js" ></script>
<script src="<?=base_url(); ?>statics/js/jquery-1.8.2.min.js" ></script>
<script src="<?=base_url(); ?>statics/js/reporte.js" ></script>
<script src="<?=base_url(); ?>statics/js/actores.js" ></script>
<script>var base = "<?=base_url(); ?>";</script>
		