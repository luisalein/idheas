<?php if ( ! defined('BASEPATH')) exit('No se permite el acceso directo al script');

class Traer_catalogos_l {
        
    function traer_todos(){
        
        
        
    }
    
}
    
?>