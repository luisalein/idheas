<?php

class casosNucleo_c extends CI_Controller {
    
    function __construct() {
        parent::__construct();
          $this->load->model(array('actores_m', 'casos_m', 'catalogos_m', 'actores_m', 'general_m'));
    }
/**Las siguientes funciones pertenecen a la parte de Nucleo Caso **/

    function index($casoId) /***Funcion que carga los detalles de la información personal***/
	{
		$this->load->helper(array('html', 'url'));					
		
        $DatosGenerales['casoId'] = $casoId; 
		$DatosGenerales['derechosAfectados']= $this->catalogos_m->mTraerDatosCatalogoDerechosAfectados();
		$DatosGenerales['actos']= $this->catalogos_m->mTraerDatosCatalogoActos();
		$DatosGenerales['lugares']= $this->catalogos_m->mTraerDatosCatalogoPaises();
	
		$this->load->view('casos/formularioActo_v', $DatosGenerales);
	
		
	}
       
       public function traerCatalogos(){
           
           $catalogos = array('estadosCatalogo', 'estatusPerpetradorCatalogo', 'estatusVictimaCatalogo', 'gruposIndigenas', 'idiomaCatalogo', 'municipiosCatalogo', 'nivelConfiabilidadCatalogo', 'ocupacionesCatalogo', 'paisesCatalogo', 'relacionActoresCatalogo', 'tipoFuenteCatalogo', );

            foreach($catalogos as $catalogo){

                $datos[$catalogo] = $this->catalogos_m->mTraerDatosCatalogoNombre($catalogo);

            }

            $datos['actos'] = $this->catalogos_m->mTraerDatosCatalogoActos();

            $datos['derechos'] = $this->catalogos_m->mTraerDatosCatalogoDerechosAfectados();

            $datos['tipoIntervencion'] = $this->catalogos_m->mTraerDatosCatalogoTipoIntervencion();
            
            $datos['tipoLugar'] = $this->catalogos_m->mTraerDatosCatalogoTipoLugar();

            $datos['tipoPerpetrador'] = $this->catalogos_m->mTraerDatosCatalogoTipoPerpetrador();
            
            $datos['listaDeCasos']= $this->casos_m->mListaCasos();

            $datos['listaDeCasos']= $this->casos_m->mListaCasos();
            
            return($datos);

       }
       	
	
    function intervenciones($casoId) /**función que carga el seguimiento de casos**/
	{
		$this->load->helper(array('html', 'url'));					

        $DatosGenerales['casoId'] = $casoId; 
        $DatosGenerales['catalogos'] = $this->traerCatalogos();
        $DatosGenerales['listaActores'] = $this->actores_m->mTraerActores();

		$this->load->view('casos/formularioIntervencion',$DatosGenerales);
	}

/**Terminan las funciones que pertenecen a la parte de información general de la sección de casos**/	
}


?>

